//
//  StarterView.swift
//  UefaScreen
//
//  Created by Tejas Kashid on 01/07/24.
//

import SwiftUI

struct StarterView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    StarterView()
}
