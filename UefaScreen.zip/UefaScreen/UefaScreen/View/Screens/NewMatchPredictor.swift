//
//  NewMatchPredictor.swift
//  UefaScreen
//
//  Created by Tejas Kashid on 14/06/24.
//

import SwiftUI

struct NewMatchPredictor: View {
    var body: some View {
        ScrollView(.vertical) {
//            VStack(spacing:0) {
//                MatchCard()
//                    .padding(.horizontal,100)
////                    .padding(.horizontal,UIScreen.main.bounds.width/2)
//            }
            
        }
        .background(Color("darkBlue000D40"))
    }
}

#Preview {
    NewMatchPredictor()
}
